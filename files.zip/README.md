# India Attention Map

> A live AI-powered map of India's political and social attention.

## What this is

A full-stack web app that scrapes Google News RSS (8 Indian languages), classifies narratives and emotions with keyword analysis, scores each state's "attention" using a decay-weighted algorithm, and generates AI summaries via OpenAI GPT-4o-mini.

---

## Deploy to Railway in ~10 minutes (no CLI needed)

### Step 1 — Push to GitHub

1. Create a new GitHub repo (public or private).
2. Upload all files from this folder:
   - `backend.py`
   - `index.html`
   - `requirements.txt`
   - `railway.toml`
   - `Procfile`

### Step 2 — Connect to Railway

1. Go to [railway.app](https://railway.app) and sign in with GitHub.
2. Click **New Project → Deploy from GitHub repo**.
3. Select your repo. Railway auto-detects `railway.toml` and starts building.

### Step 3 — Add your OpenAI API key

1. In Railway, click your service → **Variables** tab.
2. Add:
   ```
   OPENAI_API_KEY = sk-...your-key-here...
   ```
3. Railway redeploys automatically.

### Step 4 — Get your URL

Railway gives you a public URL like `https://india-attention-map-production.up.railway.app`.

Open it — you'll see the India map. The backend ingests real Google News data on startup (~60 seconds), then the map populates with live attention scores.

---

## How it works

```
Startup
  └─ run_ingest() fires in background
       └─ Google News RSS × 30 states × 3 languages
            └─ Each headline: geotag → narrative classify → emotion classify
                 └─ Store in memory, compute attention scores
                      └─ OpenAI GPT-4o-mini generates state summaries
                           └─ /api/states serves heatmap data
                                └─ Frontend map colors + panel updates
```

**Attention score formula:**
```
score = 100 × tanh(weighted_signal_volume / 22)
Each signal's weight decays with half-life = 36 hours
```

---

## Local development

```bash
# Clone your repo
git clone https://github.com/you/india-attention-map
cd india-attention-map

# Install deps
pip install -r requirements.txt

# Set your key
export OPENAI_API_KEY=sk-...

# Run backend
python backend.py

# Open browser → http://localhost:8000
```

The frontend (`index.html`) is served at `/` by FastAPI itself — no separate server needed.

---

## API endpoints

| Endpoint | Description |
|---|---|
| `GET /` | Serves the frontend |
| `GET /api/states` | Heatmap data — all states, attention scores |
| `GET /api/state/{name}` | Full detail for one state |
| `GET /api/snapshot/daily` | National summary stats |
| `POST /api/ingest/run` | Trigger a fresh ingestion cycle |
| `GET /api/health` | Backend status + last ingest time |

---

## Refresh data manually

Visit `POST /api/ingest/run` (use curl or any REST client):

```bash
curl -X POST https://your-app.up.railway.app/api/ingest/run
```

In production you'd set a Railway cron job or an external scheduler (e.g. cron-job.org hitting this endpoint every 15 minutes).

---

## Cost estimate (Railway)

| Item | Monthly |
|---|---|
| Railway Hobby plan | $5 base |
| Memory (512MB–1GB) | ~$5–10 |
| OpenAI GPT-4o-mini (~500 calls/day) | ~$1–3 |
| **Total** | **~$11–18/mo** |

---

## Upgrade path

When ready to scale:

1. **Add PostgreSQL** on Railway (one click) and replace the `Store` class with `asyncpg` queries using the schema in `ARCHITECTURE.md`.
2. **Add Redis** on Railway for caching `/api/states` responses.
3. **Add a cron job** (Railway's built-in scheduler or cron-job.org) to POST `/api/ingest/run` every 15 minutes.
4. **Add pgvector** for semantic deduplication as described in `ARCHITECTURE.md`.

---

## Editorial principles

- **No political framing.** Summaries describe attention patterns, not positions.
- **No outcome prediction.** The system measures present attention only.
- **Neutral language.** All narratives scored symmetrically across the political spectrum.
- **Transparent decay.** Scores cool automatically; a spike never dominates permanently.
